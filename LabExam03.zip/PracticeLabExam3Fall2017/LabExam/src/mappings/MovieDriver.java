/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappings;

/**
 *
 * @author Instructor
 */
public class MovieDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Create a Scanner object to read Actor and movie details from "input.txt" file.
        
        //Create an object of MovieMapping and name it as "directed".
        
        //Declare an object for Person, name it as "actor" and initialize it to null
        
        //while input.txt has more data(While loop starts here) {
        
        //Read the first line,If the passed type is "Actor" then, read in the "name".
        
        //Create an object for Person with above read value and assign it to "actor" variable.
        
        //Else, read the next line, It will be in the following order: revenue, director name and moviereleaseyear separated by '-' separator.
        
        // With above read values, create an object Movie and name it a "movie".
        
        //Invoke addMovie() on "directed" object and add the "actor","movie".
        
        // } (while loop ends here)

        // Invoke findNumberOfActors() on "directed" object and find
        // number of actors acted with "Sanjay Leela Bansali" in the year "2015", with revenue "40k"

        // Invoke findRevenuesMadeByDirector() on "directed" object and find
        // Revenues made by "Pete Docter".
       
        
        // Invoke findActorsActed() on "directed" object and find
        // actor acted for "130k" in "2016"
        
        // Print size of the hash map.
        
        
    }
    
}
