/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappings;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Instructor
 */
public class MovieMapping implements Iterable {

    private HashMap<Person, LinkedList<Movie>> actorsActed;

    public MovieMapping() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void addMovie(Person person, Movie movie) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Assume a director only directs one movie in a given year.
    public int findNumberOfActors(String directorName, String releasedYear, String revenue) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Set<String> findRevenuesMadeByDirector(String directorName) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public List<Person> findActorsActed(String genre, String releasedYear) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public HashMap<Person, LinkedList<Movie>> getActorsActed() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Iterator iterator() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
