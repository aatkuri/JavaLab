/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappings;

/**
 *
 * @author Instructor
 */
public class Movie {
    
    private String revenue;//revenue of the movie
    private Person director;//director of the movie
    private String movieReleasedYear;//release year of the movie

    public Movie(String revenue, Person director, String movieReleasedYear) {
       throw new UnsupportedOperationException("Not supported yet.");
    }
 
    public String getMovieRevenue() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getMovieReleaseYear() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Person getDirector() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
  
   
}
