/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservations;



/**
 *
 * @author 
 */
public class ReservationDriver {

    public static void main(String[] args) {

        
        //Declare and initialize a scanner object to read from the file "inputFile.txt"
        
        //create an object for ReservationList named as "reservationList"
        
        //While inputFile.txt has more data(While loop starts here) {
        //Read in the data
        
            
        //create an object for Route named as "route" and 
        //initialize the multiple argument constructor with the values from file.
        
        /*create an object for Reservation named as "reservation" 
         and initialize the multiple argument constructor with the values from file.
         Hint: use valueOf() method while passing the String where enum is required.
         For example, to pass DELTA from input file to Reservation constructor, use Airline.valueOf("DELTA").*/
            
        // Invoke addReservation method on reservationList object and add reservation.
           

        
        // }While Loop ends here

        /*Use an enhanced for loop and iterate through getReserveList() method  on reservationList object.
         and print the reservations.
        */

        /*Use an enhanced for loop and iterate through findAllSourceLocations() method on reservationList object.
         pass "DAL" as parameter.
         and print the reservations.
        */

        /*Use an enhanced for loop and iterate through findAllSourceLocations() method on reservationList object.
         pass "MCI" as parameter.
         and print the reservations.
        */
    }

}
